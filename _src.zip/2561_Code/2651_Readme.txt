The code folders are named chapterwise. 
Each folder contains the code files for that particular chapter, which you can use directly for testing the code in the book. 
